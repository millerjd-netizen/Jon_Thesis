Experiment 1 data
Window: Mar 28 07:50 PM to Mar 29 06:33 PM EST
Firmware: v12
Phase duration: 90 min
Baseline: 50:50 urine/AJ split

MFC sensor: relay-isolated on main Arduino (Digester Tank 1)
  Variable: cloud_MFC_mV  (NOT Chickie — relay used for Exps 1-2)
  Source: Digester_Tank_1-cloud_MFC_mV__1_.csv

Files:
  Digester_Tank_1-cloud_stressState.csv
  Digester_Tank_1-cloud_ORP_mV.csv
  Digester_Tank_1-cloud_Q_spir_mL.csv
  Digester_Tank_1-cloud_Q_urine_mL.csv
  Digester_Tank_1-cloud_stressCycle.csv
  Digester_Tank_1-cloud_Temp_C.csv
  Digester_Tank_1-cloud_pH.csv
  Digester_Tank_1-cloud_Q_kombucha_mL.csv
  Digester_Tank_1-cloud_VFA_mL.csv
  Digester_Tank_1-cloud_EC_mS.csv
  Digester_Tank_1-cloud_MFC_mV.csv
