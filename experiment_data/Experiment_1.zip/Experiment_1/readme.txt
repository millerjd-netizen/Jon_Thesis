Experiment 1 data
Window: Mar 28 08:13 PM to Mar 29 07:38 PM EST
        2026-03-29 00:13:00+00:00 to 2026-03-29 23:38:00+00:00 UTC

Firmware: v12
Phase duration: 90 min
Baseline: 50:50 urine/AJ split
MFC sensor: relay-isolated on main Arduino (cloud_MFC_mV)
