Experiment 2 data
Window: Mar 30 12:05 AM to Mar 31 10:12 AM EST
        2026-03-30 04:05:00+00:00 to 2026-03-31 14:12:00+00:00 UTC

Firmware: v13
Phase duration: 90 min
Baseline: 50:50 urine/AJ split
MFC sensor: relay-isolated on main Arduino (cloud_MFC_mV)
